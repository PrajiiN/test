// Initialize book list
let books = [];

// Get DOM elements
const bookList = document.getElementById('book-list');
const addBookBtn = document.getElementById('add-book-btn');
const addBookForm = document.getElementById('add-book-form');
const cancelBtn = document.getElementById('cancel-btn');

// Render book list
function renderBookList() {
    // Clear existing book list
    bookList.innerHTML = '';

    // Render each book
    for (let i = 0; i < books.length; i++) {
        const book = books[i];
        const bookElem = document.createElement('div');
        bookElem.classList.add('book');
        bookElem.innerHTML = `
      <h3>${book.title}</h3>
      <p>by ${book.author}</p>
    `;
        bookList.appendChild(bookElem);
    }
}

// Show add book form
function showAddBookForm() {
    addBookForm.classList.remove('hidden');
    addBookBtn.classList.add('hidden');
    title.value="";
    author.value="";

}

// Hide add book form
function hideAddBookForm() {
    addBookForm.classList.add('hidden');
    addBookBtn.classList.remove('hidden');
}

// Handle form submit
function handleFormSubmit(event) {
    event.preventDefault();
    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    books.push({
        title,
        author
    });
    
    hideAddBookForm();
    renderBookList();
}

// Add event listeners
addBookBtn.addEventListener('click', showAddBookForm);
cancelBtn.addEventListener('click', hideAddBookForm);
addBookForm.addEventListener('submit', handleFormSubmit);

// Render initial book list
renderBookList();